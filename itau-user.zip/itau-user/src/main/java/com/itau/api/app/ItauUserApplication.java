package com.itau.api.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItauUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItauUserApplication.class, args);
	}

}
